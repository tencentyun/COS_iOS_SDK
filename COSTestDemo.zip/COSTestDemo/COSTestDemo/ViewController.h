//
//  ViewController.h
//  COSTestDemo
//
//  Created by 贾立飞 on 16/8/24.
//  Copyright © 2016年 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface ViewController : BaseViewController


@end

